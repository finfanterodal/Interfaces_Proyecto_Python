Guía Usuario
***************
Su funcionamiento es sencillo, al ejecutarse aparece un menu con 4 opciones para navegar a las distintas funcionalidades.
En la primera Gestión de clientes, se podrán añadir nuevos clientes, modificarlos escogiendo mediante un combo box su dni
y eliminarlos. A continuación tenemos la Gestión de productos en la que podemos asignar productos a clientes.
Y por último el botón para acceder a la ventana de Albaranes en el que podemos listar clientes y sus productos asignados mediante un treview que recoge el cliente seleccionado
y a su vez también crear factura para el cliente seleccionado o generar una lista de clientes en general.
Por último tenemos un botón para salir de la app, aunque es posible salir en cualquier momento utilizando la pestaña de cerrar y también es posible volver al inicio desde cluaquier ventana.

